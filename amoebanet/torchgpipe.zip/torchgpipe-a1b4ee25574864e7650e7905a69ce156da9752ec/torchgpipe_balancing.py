# 'torchgpipe_balancing' has moved to 'torchgpipe.balance' in v0.0.5.
raise ImportError("import 'torchgpipe.balance' instead")
